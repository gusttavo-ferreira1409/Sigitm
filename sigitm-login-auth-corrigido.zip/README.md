# SIGITM Gestores — login e autenticação

Este pacote implementa a tela de login baseada na referência visual e a autenticação usando Node.js, Express e SQL Server (`Planejamento_GI`).

## Importante antes de integrar

- O pacote cria apenas a tabela nova `dbo.UsuariosSIGITM` para contas de acesso.
- Não apaga, recria nem modifica as tabelas existentes de gestores.
- A página `inicio.html` é um destino provisório após login. Troque o redirecionamento em `public/js/login.js` para a página principal que já existe no projeto.
- Para ligar a autenticação ao projeto atual sem duplicar arquivos ou quebrar as telas existentes, copie os arquivos para a estrutura do projeto e mescle as rotas no servidor atual.

## Organização dos arquivos do front-end

- `public/index.html`: somente estrutura HTML e referências externas.
- `public/css/estilo.css`: estilos da tela de login.
- `public/js/login.js`: comportamento e chamada da API de login.
- `public/css/inicio.css` e `public/js/inicio.js`: arquivos separados da página inicial.

O HTML usa referências externas (`link` e `script src`); o código CSS e JavaScript não está embutido nos arquivos HTML.

## 1. Pré-requisitos

Instale Node.js LTS e tenha acesso ao SQL Server. No terminal, dentro desta pasta:

```bash
npm install
```

## 2. Configurar variáveis

1. Copie `.env.example` para `.env`.
2. Preencha servidor, usuário e senha do SQL Server.
3. Gere um valor longo e aleatório para `JWT_SECRET`.
4. Defina `ADMIN_EMAIL`, `ADMIN_NOME` e `ADMIN_SENHA` temporariamente para criar o primeiro administrador.
5. Não envie o arquivo `.env` ao GitHub nem compartilhe credenciais.

Se o SQL Server usa autenticação integrada do Windows, esta configuração com usuário/senha SQL pode precisar ser adaptada ao ambiente da empresa.

## 3. Criar a tabela de autenticação

No SQL Server Management Studio:
1. Selecione/abra `database/usuarios-sigitm.sql`.
2. Execute o script no servidor correto.
3. Ele cria `dbo.UsuariosSIGITM` apenas se a tabela ainda não existir.

## 4. Criar o administrador inicial

Com o `.env` preenchido, execute:

```bash
npm run criar-admin
```

A senha é armazenada como hash bcrypt, não em texto puro. Após criar a conta, remova `ADMIN_SENHA` do `.env` e mantenha as credenciais em local seguro.

## 5. Iniciar

```bash
npm start
```

Abra `http://localhost:3000`. Não abra `index.html` diretamente pelo explorador: a tela precisa do servidor para chamar a API.

## 6. Criar usuários

A rota `POST /api/autenticacao/usuarios` exige uma sessão de administrador. Envie JSON:

```json
{
  "nome": "Nome do integrante",
  "email": "integrante@empresa.com.br",
  "senha": "UmaSenhaForteCom12",
  "perfil": "membro"
}
```

O campo `perfil` aceita `membro` ou `administrador`. A rota `GET /api/autenticacao/usuarios` lista contas e também exige administrador.

## Endpoints

- `POST /api/autenticacao/login`
- `GET /api/autenticacao/eu`
- `POST /api/autenticacao/logout`
- `POST /api/autenticacao/usuarios` (administrador)
- `GET /api/autenticacao/usuarios` (administrador)

## Produção

- Use HTTPS e defina `COOKIE_SECURE=true`.
- Guarde `JWT_SECRET` e credenciais em um cofre de segredos da empresa.
- Configure limitação de tentativas de login, registro de auditoria e política de troca de senha antes de publicar para uso corporativo.
- Confirme com a equipe de TI se o servidor pode conectar ao SQL Server e qual método de autenticação é aprovado.
