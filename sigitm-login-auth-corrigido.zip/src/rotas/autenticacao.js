const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { obterBanco, sql } = require("../banco");
const { validarSessao, somenteAdministrador } = require("../middleware/validarSessao");

const rotas = express.Router();
const COOKIE_NOME = "sigitm_sessao";

function configurarCookie(res, token) {
  res.cookie(COOKIE_NOME, token, {
    httpOnly: true,
    secure: String(process.env.COOKIE_SECURE).toLowerCase() === "true",
    sameSite: "strict",
    maxAge: 8 * 60 * 60 * 1000,
    path: "/"
  });
}

rotas.post("/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const senha = String(req.body.senha || "");

  if (!email || !senha) {
    return res.status(400).json({ mensagem: "Informe o e-mail corporativo e a senha." });
  }

  try {
    const banco = await obterBanco();
    const resultado = await banco.request()
      .input("email", sql.NVarChar(254), email)
      .query(`
        SELECT id, nome, email, senha_hash, perfil, ativo
        FROM dbo.UsuariosSIGITM
        WHERE email = @email
      `);

    const usuario = resultado.recordset[0];
    const senhaValida = usuario && await bcrypt.compare(senha, usuario.senha_hash);

    if (!usuario || !senhaValida || !usuario.ativo) {
      return res.status(401).json({ mensagem: "E-mail ou senha inválidos." });
    }

    await banco.request()
      .input("id", sql.Int, usuario.id)
      .query("UPDATE dbo.UsuariosSIGITM SET ultimo_acesso = SYSDATETIME() WHERE id = @id");

    const token = jwt.sign({
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email,
      perfil: usuario.perfil
    }, process.env.JWT_SECRET, { expiresIn: "8h" });

    configurarCookie(res, token);
    return res.json({
      mensagem: "Login realizado com sucesso.",
      usuario: { id: usuario.id, nome: usuario.nome, email: usuario.email, perfil: usuario.perfil }
    });
  } catch (erro) {
    console.error("Erro no login:", erro.message);
    return res.status(500).json({ mensagem: "Não foi possível realizar o login." });
  }
});

rotas.get("/eu", validarSessao, (req, res) => {
  res.json({ usuario: req.usuario });
});

rotas.post("/logout", (req, res) => {
  res.clearCookie(COOKIE_NOME, { httpOnly: true, sameSite: "strict", path: "/" });
  res.json({ mensagem: "Sessão encerrada." });
});

rotas.post("/usuarios", validarSessao, somenteAdministrador, async (req, res) => {
  const nome = String(req.body.nome || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const senha = String(req.body.senha || "");
  const perfil = String(req.body.perfil || "membro");

  if (!nome || !email || !senha) {
    return res.status(400).json({ mensagem: "Preencha nome, e-mail e senha." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ mensagem: "Informe um e-mail válido." });
  }
  if (senha.length < 12) {
    return res.status(400).json({ mensagem: "A senha deve ter pelo menos 12 caracteres." });
  }
  if (!["administrador", "membro"].includes(perfil)) {
    return res.status(400).json({ mensagem: "Perfil inválido." });
  }

  try {
    const hash = await bcrypt.hash(senha, 12);
    const banco = await obterBanco();
    await banco.request()
      .input("nome", sql.NVarChar(150), nome)
      .input("email", sql.NVarChar(254), email)
      .input("hash", sql.NVarChar(255), hash)
      .input("perfil", sql.VarChar(20), perfil)
      .input("criadoPor", sql.Int, Number(req.usuario.id))
      .query(`
        INSERT INTO dbo.UsuariosSIGITM (nome, email, senha_hash, perfil, ativo, criado_por)
        VALUES (@nome, @email, @hash, @perfil, 1, @criadoPor)
      `);
    return res.status(201).json({ mensagem: "Usuário cadastrado com sucesso." });
  } catch (erro) {
    if (erro.number === 2627 || erro.number === 2601) {
      return res.status(409).json({ mensagem: "Já existe um usuário com esse e-mail." });
    }
    console.error("Erro ao cadastrar usuário:", erro.message);
    return res.status(500).json({ mensagem: "Não foi possível cadastrar o usuário." });
  }
});

rotas.get("/usuarios", validarSessao, somenteAdministrador, async (req, res) => {
  try {
    const banco = await obterBanco();
    const resultado = await banco.request().query(`
      SELECT id, nome, email, perfil, ativo, criado_em, ultimo_acesso
      FROM dbo.UsuariosSIGITM
      ORDER BY nome
    `);
    res.json({ usuarios: resultado.recordset });
  } catch (erro) {
    console.error("Erro ao listar usuários:", erro.message);
    res.status(500).json({ mensagem: "Não foi possível listar os usuários." });
  }
});

module.exports = rotas;