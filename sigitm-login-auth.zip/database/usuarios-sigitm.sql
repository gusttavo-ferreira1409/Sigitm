USE [Planejamento_GI];
GO

IF OBJECT_ID('dbo.UsuariosSIGITM', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.UsuariosSIGITM (
        id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_UsuariosSIGITM PRIMARY KEY,
        nome NVARCHAR(150) NOT NULL,
        email NVARCHAR(254) NOT NULL,
        senha_hash NVARCHAR(255) NOT NULL,
        perfil VARCHAR(20) NOT NULL CONSTRAINT DF_UsuariosSIGITM_perfil DEFAULT ('membro'),
        ativo BIT NOT NULL CONSTRAINT DF_UsuariosSIGITM_ativo DEFAULT (1),
        criado_em DATETIME2 NOT NULL CONSTRAINT DF_UsuariosSIGITM_criado_em DEFAULT (SYSDATETIME()),
        criado_por INT NULL,
        ultimo_acesso DATETIME2 NULL,
        CONSTRAINT UQ_UsuariosSIGITM_email UNIQUE (email),
        CONSTRAINT CK_UsuariosSIGITM_perfil CHECK (perfil IN ('administrador', 'membro'))
    );
END;
GO