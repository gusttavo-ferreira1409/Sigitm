async function carregarUsuario() {
  const nome = document.querySelector("#nome-usuario");
  const perfil = document.querySelector("#perfil-usuario");

  try {
    const resposta = await fetch("/api/autenticacao/eu", { credentials: "same-origin" });
    if (!resposta.ok) {
      window.location.replace("/");
      return;
    }
    const dados = await resposta.json();
    nome.textContent = dados.usuario.nome;
    perfil.textContent = dados.usuario.perfil;
    document.querySelector(".avatar").textContent = dados.usuario.nome.trim().charAt(0).toUpperCase();
  } catch {
    window.location.replace("/");
  }
}

document.querySelector("#sair").addEventListener("click", async () => {
  await fetch("/api/autenticacao/logout", { method: "POST", credentials: "same-origin" });
  sessionStorage.removeItem("sigitm_usuario_nome");
  sessionStorage.removeItem("sigitm_usuario_perfil");
  window.location.replace("/");
});

carregarUsuario();