const formulario = document.querySelector("#formulario-login");
const campoEmail = document.querySelector("#email");
const campoSenha = document.querySelector("#senha");
const mensagem = document.querySelector("#mensagem");
const botaoLogin = document.querySelector("#botao-login");
const alternarSenha = document.querySelector("#alternar-senha");

alternarSenha.addEventListener("click", () => {
  const vaiMostrar = campoSenha.type === "password";
  campoSenha.type = vaiMostrar ? "text" : "password";
  alternarSenha.setAttribute("aria-label", vaiMostrar ? "Ocultar senha" : "Mostrar senha");
});

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  mensagem.textContent = "";

  const email = campoEmail.value.trim();
  const senha = campoSenha.value;

  if (!email || !senha) {
    mensagem.textContent = "Preencha o e-mail corporativo e a senha.";
    return;
  }

  botaoLogin.disabled = true;
  botaoLogin.textContent = "Entrando...";

  try {
    const resposta = await fetch("/api/autenticacao/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ email, senha })
    });

    const dados = await resposta.json();

    if (!resposta.ok) {
      mensagem.textContent = dados.mensagem || "Não foi possível entrar.";
      return;
    }

    sessionStorage.setItem("sigitm_usuario_nome", dados.usuario.nome);
    sessionStorage.setItem("sigitm_usuario_perfil", dados.usuario.perfil);
    window.location.assign("/inicio.html");
  } catch {
    mensagem.textContent = "Não foi possível conectar ao servidor. Tente novamente.";
  } finally {
    botaoLogin.disabled = false;
    botaoLogin.textContent = "Logar";
  }
});