require("dotenv").config();
const bcrypt = require("bcryptjs");
const { obterBanco, sql } = require("../src/banco");

async function criarAdmin() {
  const nome = String(process.env.ADMIN_NOME || "").trim();
  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const senha = String(process.env.ADMIN_SENHA || "");

  if (!nome || !email || senha.length < 12) {
    throw new Error("Defina ADMIN_NOME, ADMIN_EMAIL e ADMIN_SENHA com pelo menos 12 caracteres no .env.");
  }

  const banco = await obterBanco();
  const existente = await banco.request()
    .input("email", sql.NVarChar(254), email)
    .query("SELECT id FROM dbo.UsuariosSIGITM WHERE email = @email");

  if (existente.recordset.length) {
    console.log("Já existe um usuário com esse e-mail. Nenhuma alteração foi feita.");
    return;
  }

  const hash = await bcrypt.hash(senha, 12);
  await banco.request()
    .input("nome", sql.NVarChar(150), nome)
    .input("email", sql.NVarChar(254), email)
    .input("hash", sql.NVarChar(255), hash)
    .query(`
      INSERT INTO dbo.UsuariosSIGITM (nome, email, senha_hash, perfil, ativo)
      VALUES (@nome, @email, @hash, 'administrador', 1)
    `);

  console.log("Administrador criado. Por segurança, remova ADMIN_SENHA do .env após a configuração.");
}

criarAdmin()
  .catch((erro) => {
    console.error("Não foi possível criar o administrador:", erro.message);
    process.exitCode = 1;
  });