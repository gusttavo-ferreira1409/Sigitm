require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const path = require("path");
const authRoutes = require("./src/rotas/autenticacao");
const { testarConexao } = require("./src/banco");

const app = express();
const PORTA = process.env.PORT || 3000;

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"]
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.use("/api/autenticacao", authRoutes);

app.get("/api/status", (req, res) => {
  res.json({ funcionando: true, sistema: "SIGITM Gestores" });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

async function iniciar() {
  try {
    await testarConexao();
    app.listen(PORTA, () => {
      console.log(`SIGITM Gestores disponível em http://localhost:${PORTA}`);
    });
  } catch (erro) {
    console.error("Não foi possível conectar ao SQL Server:", erro.message);
    process.exit(1);
  }
}

iniciar();