const sql = require("mssql");

const configuracao = {
  server: process.env.DB_SERVER,
  port: Number(process.env.DB_PORT || 1433),
  database: process.env.DB_NAME || "Planejamento_GI",
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    encrypt: String(process.env.DB_ENCRYPT).toLowerCase() === "true",
    trustServerCertificate: String(process.env.DB_TRUST_SERVER_CERTIFICATE).toLowerCase() === "true"
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

let poolPromise;

function obterBanco() {
  if (!poolPromise) {
    poolPromise = new sql.ConnectionPool(configuracao).connect()
      .catch((erro) => {
        poolPromise = null;
        throw erro;
      });
  }
  return poolPromise;
}

async function testarConexao() {
  const pool = await obterBanco();
  await pool.request().query("SELECT 1 AS conectado");
}

module.exports = { sql, obterBanco, testarConexao };