const jwt = require("jsonwebtoken");

function validarSessao(req, res, next) {
  const token = req.cookies.sigitm_sessao;
  if (!token) {
    return res.status(401).json({ mensagem: "Faça login para continuar." });
  }

  try {
    req.usuario = jwt.verify(token, process.env.JWT_SECRET);
    return next();
  } catch {
    res.clearCookie("sigitm_sessao");
    return res.status(401).json({ mensagem: "Sessão expirada. Entre novamente." });
  }
}

function somenteAdministrador(req, res, next) {
  if (req.usuario?.perfil !== "administrador") {
    return res.status(403).json({ mensagem: "Apenas administradores podem realizar esta ação." });
  }
  return next();
}

module.exports = { validarSessao, somenteAdministrador };